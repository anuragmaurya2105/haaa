cd ..

git clone https://github.com/libDrive/cloudflare.git
git clone https://github.com/libDrive/config.git
git clone https://github.com/libDrive/heroku.git
git clone https://github.com/libDrive/libdrive.github.io.git
git clone https://github.com/libDrive/server.git
git clone https://github.com/libDrive/web.git
git clone https://github.com/libDrive/webhooks.git

cd libDrive
