---
name: Feature request
about: Suggest an idea for this project
title: "[ENHANCEMENT]"
labels: enhancement
assignees: ''

---

### Outline of feature request

A clear and concise description of what the feature you would like implemented is.

### Reason

Why do you think this would be a good addition to libDrive

**Additional information**
Add any other extra information or screenshots about the feature request here.
